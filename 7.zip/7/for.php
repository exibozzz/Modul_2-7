<?php



for($i=0; $i <15; $i++)  {echo $i;}

//  ukoliko u for petlja ne bi sadrzala $i++ kod bi se izvrsavao zauvek sto bi stvorilo infinite loop. 
//  infinite loop je petlja koja traje konstantno - zauvek.

//  $i = 0;
//  echo $i;
//  $i = 1;
//  echo $i;   itd sve do 100.

 

?>