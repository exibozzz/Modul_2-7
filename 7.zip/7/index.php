<?php

$automobili = ["Nissan", "Mazda", "Toyota"];

foreach($automobili as $automobil)


// --------------------------------------------------------






























?>