<?php



/* 



    Napraviti array koji sadrzi niz brojeva.

    Preko provere utvrditi da li je broj paran ili neparan 

    Ukoliko je broj neparan >>> continue

    Prikazati preko echo samo parne brojeve

 */



$brojevi = [22, 53, 36, 46, 13, 65, 12, 75, 424, 151, 168, 247, 335];

foreach($brojevi as $broj){

$proveraBroja = $broj % 2;

if ($proveraBroja == 1) {continue;}

echo $broj;

}



// Tomo s'obzirom da nema konkretnog domaceg za ovo predavanje kombinovao sam neke vezbe poput ove
// Interesuje me gde u praksi mogu da implementiram foreach poput "prikazi sve brojeve mnozive sa 9" itd.
// Baci neke dodatne primere kad budes bacio oko . pozz


















?>